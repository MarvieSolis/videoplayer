import Sniffer from './Sniffer.js';
import './video-player.css';

let buttonFaderHandler = function(e) {
    if (Sniffer.sniff().isMobileDevice) return;
    switch(e.type) {
        case "mouseover":
            e.currentTarget.getElementsByClassName("detail")[0].style.opacity = 1;
            break;
        case "mouseout":
            e.currentTarget.getElementsByClassName("detail")[0].style.opacity = 0;
            break;
    }
};

let ButtonUtil = {
    buttonFaderHandler: buttonFaderHandler,
};

export {ButtonUtil};