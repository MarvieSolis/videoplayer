import React from "react";
import Sniffer from './Sniffer.js';
import './video-player.css';

class VideoCuepoint {
    constructor(id, time) {
        this.id = id;
        this.time = time;
        this.enabled = true;
    }
}

class VideoPlayer extends React.Component {

    constructor(props) {
        super(props);
        this.observers = [];
        this.cuepoints = [];
        this.videoPlaying = this.videoPlaying.bind(this);
        this.videoError = this.videoError.bind(this);
        this.videoComplete = this.videoComplete.bind(this);
        this.videoProgress = this.videoProgress.bind(this);
        this.startFullscreen = this.startFullscreen.bind(this);
        this.endFullscreen = this.endFullscreen.bind(this);
        this.videoFullscreenChangeHandler = this.videoFullscreenChangeHandler.bind(this);
        this.mouseMoveHandler = this.mouseMoveHandler.bind(this);
        this.mouseMovePlayerHandler = this.mouseMovePlayerHandler.bind(this);
        this.mouseUpHandler = this.mouseUpHandler.bind(this);
        this.updateScrubber = this.updateScrubber.bind(this);
        this.scrubHandler = this.scrubHandler.bind(this);
        this.constantTimerHandler = this.constantTimerHandler.bind(this);
        this.play = this.play.bind(this);
        this.pause = this.pause.bind(this);
        this.mute = this.mute.bind(this);
        this.unmute = this.unmute.bind(this);
        this.videoError = this.videoError.bind(this);
        this.startFullscreen = this.startFullscreen.bind(this);
        this.endFullscreen = this.endFullscreen.bind(this);
        this.togglePlayPause = this.togglePlayPause.bind(this);
        this.windowFocusHandler = this.windowFocusHandler.bind(this);
        this.time = 0;
        this.wasPlayingBeforeScrubbing = false;
        this.isDraggingScrubber = false;
        this.scrubberX = 0;
        this.scrubberMaxX = 0;
        this.scrubberMinX = 0;
        this.scrubberInterval = 0;
        this.leftControlsWidth = 60;
        this.rightControlsWidth = 30;
        this.scrubberHandleOffsetX = 5;
        this.autoHideControlsTimer = 0;
        this.constantVideoPlaybackInterval = 0;
        this._isVideoPlaying = false;
        this.start();
    }

    start() {
        this._isVideoPlaying = false;
        this.time = 0;
        this.render();
        setTimeout(() => {
            this.getElement().muted = true;
            this.getElement().setAttribute("muted", "");
            document.querySelector("#" + this.props.id + "-container div.video-loader").style.display = "block";
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
            document.querySelector("#" + this.props.controllerId + " div.video-controls").style.opacity = 1;
            document.querySelector("#" + this.props.controllerId + " > div.video-controls > div.video-progress-container").style.left = (this.leftControlsWidth) + "px";
            this.getElement().parentNode.style.maxWidth = this.props.maxWidth + "px";
            /* TAILOR CONTROLS */
            if (Sniffer.sniff().data.isMobileDevice) {
                this.leftControlsWidth = 30;
            }
            if (Sniffer.isIE()) {
                if (Sniffer.isIE() <= 11) {
                    this.rightControlsWidth = 0;
                    document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "none";
                    document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
                }
            }
            if (!this.getFullscreenEnabled()) {
                this.rightControlsWidth = 0;
                document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "none";
                document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
            }
            if (Sniffer.sniff().data.isMobileDevice) {
                document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "none";
                document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "none";
            }
            this.updateController();
            if (this.props.autoplay === "true") {
                document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.display = "none";
                document.querySelector("#" + this.props.controllerId + " button.button-play-video").style.display = "none";
                document.querySelector("#" + this.props.controllerId + " button.button-pause-video").style.display = "block";
                this.play();
            } else {
                document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.display = "block";
                document.querySelector("#" + this.props.controllerId + " button.button-play-video").style.display = "block";
                document.querySelector("#" + this.props.controllerId + " button.button-pause-video").style.display = "none";
            }
            this.enable(true);
        }, 50);
    }

    constantTimerHandler() {
        if (this.getAutoHideControls()) {
            if (this.autoHideControlsTimer === this.getAutoHideControlsTime()) {
                document.querySelector("#" + this.props.controllerId + " div.video-controls").style.opacity = 0;
            }
            if (this.autoHideControlsTimer === 0) {
                document.querySelector("#" + this.props.controllerId + " div.video-controls").style.opacity = 1;
                // alert("test");
            }
            this.autoHideControlsTimer++;
        }
    }

    destroy() {
        this.enable(false);
    }

    render() {
        return (
            <div data-width={this.props.width} data-height={this.props.height} id={this.props.id + "-container"}
                 className="video-player-container">
                <video width={this.props.width} height={this.props.height} id={this.props.id} className="video-player"
                       preload="auto" playsInline muted>
                    <source src={this.props.mp4} type='video/mp4'></source>
                    <source src={this.props.webm} type='video/webm'></source>
                </video>
                <div data-width={this.props.width} data-height={this.props.height} className="video-loader">
                    <img src={this.props.loader} alt="loading..."></img>
                </div>
                <div data-width={this.props.width} data-height={this.props.height} id={this.props.controllerId}
                     className="video-controls-container">
                    <div className="video-controls">
                        <div duration={this.props.duration} className="video-progress-container">
                            <div className="video-bar"><div className="video-bar-detail"></div></div>
                            <div className="video-progress-bar"><div className="video-progress-bar-detail"></div></div>
                            <div className="video-scrubber-handle"><div className="video-scrubber-handle-detail"></div></div>
                        </div>
                        <button type="button" className="button-play-video"><div className="detail"></div></button>
                        <button type="button" className="button-pause-video"><div className="detail"></div></button>
                        <button type="button" className="button-unmute-video"><div className="detail"></div></button>
                        <button type="button" className="button-mute-video"><div className="detail"></div></button>
                        <button type="button" className="button-start-fullscreen"><div className="detail"></div></button>
                        <button type="button" className="button-end-fullscreen"><div className="detail"></div></button>
                    </div>
                    <button type="button" className="button-toggle-play-pause"><div className="detail"></div></button>
                    <button type="button" className="button-click-to-play-video"><div className="detail"></div></button>
                </div>
            </div>
        );
    }

    play() {
        console.log("play");
        document.querySelector("#" + this.props.id + "-container div.video-loader").style.display = "block";
        let isError = false;
        let promise = this.getElement().play();
        if (promise !== undefined) {
            promise.catch((error) => {
                console.log("err 1");
                if (error) {
                    isError = true;
                }
            }).then(() => {
                document.querySelector("#" + this.props.id + "-container div.video-loader").style.display = "none";
                if (isError) {
                    console.log("err 2");
                    console.warn("video play was prevented");
                } else {
                    if ((this.time * 1000) === this.props.duration) {
                        this.resetCuePoints();
                    }
                    clearInterval(this.videoPlaybackInterval);
                    this.videoPlaybackInterval = setInterval(this.videoProgress, 30);
                    this._isVideoPlaying = true;
                }
                // this.sendNotification('video error', {}, this);
            });
        }
    }

    pause() {
        console.log("pause");
        this._isVideoPlaying = false;
        document.querySelector("#" + this.props.controllerId + " button.button-play-video").style.display = "block";
        document.querySelector("#" + this.props.controllerId + " button.button-pause-video").style.display = "none";
        this.getElement().pause();
        clearInterval(this.videoPlaybackInterval);
    }

    rewind() {
        try {
            this.getElement().currentTime = 0;
        } catch (err) {
        }
        this.resetCuePoints();
        this.pause();
    }

    mute() {
        document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "none";
        document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "block";
        this.getElement().volume = 0.0;
    }

    unmute() {
        document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "block";
        document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "none";
        try {
            this.getElement().removeAttribute("muted");
        } catch (err) {
        }
        this.getElement().volume = 1.0;
    }

    startFullscreen() {
        console.log("startFullscreen");
        let elem = this.getElement().parentNode;
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) { /* Firefox */
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) { /* IE/Edge */
            elem.msRequestFullscreen();
        }
        if (Sniffer.sniff().data.isMobileDevice) {
            this.getElement().webkitEnterFullscreen();
        } else {
            document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "none";
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "block";
            if (Sniffer.isIE()) {
                if (Sniffer.isIE() <= 11) {
                    document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "none";
                    document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
                }
            }
        }
        this.updateController();
        setTimeout(function () {
            this.updateController();
        }.bind(this), 500);
        setTimeout(function () {
            this.updateController();
        }.bind(this), 1000);
    }

    endFullscreen() {
        console.log("endFullscreen");
        if (document.fullscreenElement || /* Standard syntax */
            document.webkitFullscreenElement || /* Chrome, Safari and Opera syntax */
            document.mozFullScreenElement ||/* Firefox syntax */
            document.msFullscreenElement /* IE/Edge syntax */) {
            if (document.fullScreenElement) {
                document.cancelFullScreen();
            } else if (document.msFullscreenElement) {
                document.msExitFullscreen();
            } else if (document.mozFullScreenElement) {
                document.mozCancelFullScreen();
            } else if (document.webkitFullscreenElement) {
                document.webkitCancelFullScreen();
            } else {
                document.exitFullscreen();
            }
        }
        document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "block";
        document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
        this.updateController();
        this.autoHideControlsTimer = 0;
        setTimeout(function () {
            this.updateController();
        }.bind(this), 500);
        setTimeout(function () {
            this.updateController();
        }.bind(this), 1000);
    }

    replay() {
        this.resetCuePoints();
        this.rewind();
        this.unmute();
        this.play();
    }

    videoError() {
        document.querySelector("#" + this.props.id + "-container div.video-loader").style.display = "block";
        console.warn("_videoError");
        clearInterval(this.videoPlaybackInterval);
        // this.sendNotification('video error', {}, this);
    }

    videoPlaying() {
        console.log("videoPlaying");
        this.autoHideControlsTimer = 0;
        this._isVideoPlaying = true;
        document.querySelector("#" + this.props.id + "-container div.video-loader").style.display = "none";
        // play/pause
        document.querySelector("#" + this.props.controllerId + " button.button-play-video").style.display = "none";
        document.querySelector("#" + this.props.controllerId + " button.button-pause-video").style.display = "block";
        // mute/unmute
        if (Sniffer.sniff().data.isMobileDevice) {
            document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "none";
            document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "none";
        } else {
            if (this.getElement().volume === 0) {
                document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "none";
                document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "block";
            } else {
                document.querySelector("#" + this.props.controllerId + " button.button-mute-video").style.display = "block";
                document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").style.display = "none";
            }
        }
        document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.display = "none";
        document.querySelector("#" + this.props.controllerId + " div.video-controls").style.opacity = 1;
        this.wasPlayingBeforeScrubbing = true;
        clearInterval(this.videoPlaybackInterval);
        this.videoPlaybackInterval = setInterval(this.videoProgress, 30);
        // this.sendNotification('playing', {}, this);
    }

    videoProgress() {
        try {
            if (!this.getElement().currentTime) return;
            let i = 0;
            if (this.time > this.getElement().currentTime) {
                for (i = 0; i < this.cuepoints.length; i++) {
                    this.cuepoints[i].enabled = true;
                }
            }
            this.time = this.getCurrentTime();
            for (i = 0; i < this.cuepoints.length; i++) {
                if (this.cuepoints[i].enabled) {
                    if (((parseFloat(this.time) - 0.1) < this.cuepoints[i].time &&
                        (parseFloat(this.time) + 0.1) > this.cuepoints[i].time) ||
                        this.time === this.cuepoints[i].time) {
                        this.cuepoints[i].enabled = false;
                        // this.sendNotification(this.cuepoints[i].id, {time: this.cuepoints[i].time}, this);
                    }
                }
            }
            let progressBarWidth = parseInt(window.getComputedStyle(document.querySelector("#" + this.props.controllerId + " div.video-bar"), null).width);
            this.scrubberMaxX = progressBarWidth;
            this.scrubberMinX = 10;
            let duration = (this.props.duration * 0.001);
            try {
                let currentTime = this.getElement().currentTime;
                if (currentTime > duration) currentTime = duration;
                if (currentTime < 0) currentTime = 0;
                this.scrubberX = parseInt((currentTime / duration) * progressBarWidth);
                this.scrubberX = Math.max(this.scrubberMaxX);
                this.scrubberX = Math.min(this.scrubberMinX);
                this.updateScrubber();
            } catch (err) {
                console.warn("err.message: " + err.message);
                document.querySelector("#" + this.props.controllerId + " div.video-progress-container").style.display = "none";
            }
            let val = (this.time / duration) * this.scrubberMaxX;
            document.querySelector("#" + this.props.controllerId + " div.video-progress-bar").style.width = val + "px";
            document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle").style.left = (val - 10) + "px";
            // Update progress bar
            let w = this.props.width;
            if (this.isFullscreen()) {
                w = window.innerWidth;
            } else {
                w = window.getComputedStyle(this.getElement(), null).width.toString();
            }
            document.querySelector("#" + this.props.controllerId + " div.video-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
            /*this.sendNotification("progress", {
                time: this.getElement().currentTime,
                duration: this.props.duration
            }, this);*/
        } catch (err) {
        }
    }

    videoComplete(e) {
        console.log("videoComplete");
        clearInterval(this.videoPlaybackInterval);
        this._isVideoPlaying = false;
        if (Sniffer.sniff().data.isMobileDevice) {
            this.getElement().webkitExitFullscreen();
        }
        document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.display = "block";
        setTimeout(() => {
            // this.sendNotification("ended", {}, this);
        }, 10);
    }

    videoFullscreenChangeHandler() {
        console.log("videoFullscreenChangeHandler");
        this.updateController();
        if (this.isFullscreen()) {
            this.getElement().parentNode.style.maxWidth = "none";
            document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "none";
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "block";
        } else {
            this.getElement().parentNode.style.maxWidth = this.props.maxWidth + "px";
            document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").style.display = "block";
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").style.display = "none";
        }
        let w = window.getComputedStyle(this.getElement(), null).width.toString();
        document.querySelector("#" + this.props.controllerId + " div.video-progress-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
    }

    getCurrentTime() {
        return parseFloat(this.getElement().currentTime).toFixed(2);
    }

    getElement() {
        return document.getElementById(this.props.id);
    }

    deleteElement() {
        this.getElement().parentNode.innerHTML = "";
    }

    addCuepoint(id, time) {
        this.cuepoints.push(new VideoCuepoint(id, time));
    }

    removeCuepoints() {
        this.cuepoints = []
    }

    resetCuePoints() {
        let i, l;
        for (i = 0, l = this.cuepoints.length; i < l; i++) {
            this.cuepoints[i].enabled = true;
        }
    }

    mouseUpHandler(e) {
        this.mouseMoveHandler(e);
        if (this.isDraggingScrubber) {
            if (this.wasPlayingBeforeScrubbing) {
                try {
                    this.play();
                } catch (err) {
                }
            }
        }
        this.stopDragging();
    }

    mouseMovePlayerHandler(e) {
        this.autoHideControlsTimer = 0;
    }

    mouseMoveHandler(e) {
        if (this.isDraggingScrubber) {
            this.autoHideControlsTimer = 0;
            let progressBarWidth = parseFloat(window.getComputedStyle(document.querySelector("#" + this.props.controllerId + " div.video-bar")).width);
            let currentTime = 0;
            let duration = this.props.duration * 0.001;
            let interactionX = 0;
            if (Sniffer.sniff().data.isMobileDevice) {
                interactionX = e.changedTouches[0].clientX;
            } else {
                interactionX = e.clientX;
            }
            try {
                this.scrubberX = (interactionX + this.scrubberHandleOffsetX - this.leftControlsWidth);
                if (this.scrubberX > this.scrubberMaxX) this.scrubberX = this.scrubberMaxX;
                if (this.scrubberX < this.scrubberMinX) this.scrubberX = this.scrubberMinX;
                currentTime = (this.scrubberX / progressBarWidth) * this.props.duration;
                currentTime *= 0.001;
                if (currentTime > duration) currentTime = duration;
                if (currentTime < 0) currentTime = 0;
                this.getElement().currentTime = currentTime;
                this.updateScrubber();
            } catch (err) {
            }
        }
    }

    scrubHandler(e) {
        if (this.isVideoPlaying()) {
            this.pause();
        }
        this.isDraggingScrubber = true;
        this.mouseMoveHandler(e);
        this.updateScrubber();
        clearInterval(this.scrubberInterval);
        this.scrubberInterval = setInterval(this.updateScrubber, 100);
    }

    updateScrubber() {
        document.querySelector("#" + this.props.controllerId + " div.video-progress-bar").style.width = this.scrubberX + "px";
        document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle").style.left = (this.scrubberX - 10) + "px";
    }

    stopDragging() {
        clearInterval(this.scrubberInterval);
        this.scrubberInterval = 0;
        this.isDraggingScrubber = false;
    }

    updateController() {
        if (this.isFullscreen()) {
            this.getElement().style.width = "100%";
            this.getElement().style.height = "100%";
            document.querySelector("#" + this.props.controllerId).style.width = "100%";
            document.querySelector("#" + this.props.controllerId).style.height = "100%";
            document.querySelector("#" + this.props.controllerId + " div.video-controls").style.width = "100%";
            document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.width = "100%";
            document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").style.height = "100%";
            document.querySelector("#" + this.props.id + "-container div.video-loader").style.width = "100%";
            document.querySelector("#" + this.props.id + "-container div.video-loader").style.height = "100%";
        }
        let w = window.getComputedStyle(this.getElement(), null).width.toString();
        document.querySelector("#" + this.props.controllerId + " div.video-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
    }

    togglePlayPause() {
        if (this.isVideoPlaying()) {
            this.pause();
        } else {
            this.play();
        }
    }

    windowFocusHandler(e) {
        this.pause();
    }

    enable(value) {
        let moveEvent = "mousemove";
        let downEvent = "mousedown";
        let upEvent = "mouseup";
        if (Sniffer.sniff().data.isMobileDevice) {
            moveEvent = "touchmove";
            downEvent = "touchstart";
            upEvent = "touchend";
        }
        // HANDLERS
        try {
            document.removeEventListener("fullscreenchange", this.videoFullscreenChangeHandler, false);
            document.removeEventListener("mozfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.removeEventListener("webkitfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.removeEventListener("msfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.removeEventListener(moveEvent, this.mouseMoveHandler, false);
            document.removeEventListener(upEvent, this.mouseUpHandler, false);
        } catch (err) {
        }
        clearInterval(this.constantVideoPlaybackInterval);
        if (value) {
            document.addEventListener("fullscreenchange", this.videoFullscreenChangeHandler, false);
            document.addEventListener("mozfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.addEventListener("webkitfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.addEventListener("msfullscreenchange", this.videoFullscreenChangeHandler, false);
            document.addEventListener(moveEvent, this.mouseMoveHandler, false);
            document.addEventListener(upEvent, this.mouseUpHandler, false);
            this.constantVideoPlaybackInterval = setInterval(this.constantTimerHandler, 500);
        }
        try {
            document.querySelector("#" + this.props.controllerId).removeEventListener(downEvent, this.mouseMoveHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-bar").removeEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-progress-bar").removeEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle").removeEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " button.button-play-video").removeEventListener(downEvent, this.play, false);
            document.querySelector("#" + this.props.controllerId + " button.button-pause-video").removeEventListener(downEvent, this.pause, false);
            document.querySelector("#" + this.props.controllerId + " button.button-mute-video").removeEventListener(downEvent, this.mute, false);
            document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").removeEventListener(downEvent, this.unmute, false);
            document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").removeEventListener(downEvent, this.startFullscreen, false);
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").removeEventListener(downEvent, this.endFullscreen, false);
            document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").removeEventListener(downEvent, this.play, false);
            document.querySelector("#" + this.props.controllerId + " button.button-toggle-play-pause").removeEventListener(downEvent, this.togglePlayPause, false);
            document.querySelector("#" + this.props.controllerId).removeEventListener("mousemove", this.mouseMovePlayerHandler, false);
            this.getElement().removeEventListener("playing", this.videoPlaying, false);
            this.getElement().removeEventListener("ended", this.videoComplete, false);
            window.removeEventListener("blur", this.windowFocusHandler, false);
        } catch (err) {
        }
        if (value) {
            document.querySelector("#" + this.props.controllerId).addEventListener(downEvent, this.mouseMoveHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-bar").addEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-progress-bar").addEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle").addEventListener(downEvent, this.scrubHandler, false);
            document.querySelector("#" + this.props.controllerId + " button.button-play-video").addEventListener(downEvent, this.play, false);
            document.querySelector("#" + this.props.controllerId + " button.button-pause-video").addEventListener(downEvent, this.pause, false);
            document.querySelector("#" + this.props.controllerId + " button.button-mute-video").addEventListener(downEvent, this.mute, false);
            document.querySelector("#" + this.props.controllerId + " button.button-unmute-video").addEventListener(downEvent, this.unmute, false);
            document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen").addEventListener(downEvent, this.startFullscreen, false);
            document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen").addEventListener(downEvent, this.endFullscreen, false);
            document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video").addEventListener(downEvent, this.play, false);
            document.querySelector("#" + this.props.controllerId + " button.button-toggle-play-pause").addEventListener(downEvent, this.togglePlayPause, false);
            document.querySelector("#" + this.props.controllerId).addEventListener("mousemove", this.mouseMovePlayerHandler, false);
            this.getElement().addEventListener("playing", this.videoPlaying, false);
            this.getElement().addEventListener("ended", this.videoComplete, false);
            window.addEventListener("blur", this.windowFocusHandler, false);
        }
    }

    isVideoPlaying() {
        return this._isVideoPlaying;
    }

    isVideoComplete() {
        if (this.getElement().currentTime === this.props.duration) {
            return true;
        }
        return false;
    }

    isFullscreen() {
        if (document.fullscreenElement || /* Standard syntax */
            document.webkitFullscreenElement || /* Chrome, Safari and Opera syntax */
            document.mozFullScreenElement ||/* Firefox syntax */
            document.msFullscreenElement /* IE/Edge syntax */) {
            return true;
        } else {
            return false;
        }
    }

    getAutoHideControls() {
        if (this.props.autoHideControls) {
            if (this.props.autoHideControls === "true") {
                return true;
            }
        }
        return false;
    }

    getAutoHideControlsTime() {
        if (this.props.autoHideControlsTime) {
            return this.props.autoHideControlsTime;
        }
        return 5;
    }

    getFullscreenEnabled() {
        if (document.fullscreenEnabled ||
            document.webkitFullscreenEnabled ||
            document.mozFullScreenEnabled ||
            document.msFullscreenEnabled) {
            return true;
        }
        return false;
    }

}

export {VideoPlayer, VideoCuepoint};