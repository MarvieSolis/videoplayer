class Sprite {

    constructor(options) {
        if(!options) options = {};
        let _options = {
            name: options.name || "sprite-" + ~~(Math.random() * 100000),
            image: options.image || null,
            src: options.src || null,
            x: options.x || 30,
            y: options.y || 0,
            w: options.w || 0,
            h: options.h || 0,
        };
        this.name = _options.name;
        this.image = _options.image;
        this.src = _options.src;
        this.x = _options.x;
        this.y = _options.y;
        this.w = _options.w;
        this.h = _options.h;
    }

}

export default Sprite;