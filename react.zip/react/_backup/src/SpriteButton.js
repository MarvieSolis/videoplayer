import "./button-utils.css";
import React from "react";
import {SpriteAnimation} from "./SpriteAnimation.js";
import Sprite from "./Sprite";

class SpriteButton extends React.Component {

    constructor(props) {
        super(props);
        this.mouseHandler = this.mouseHandler.bind(this);
        let frames = [];
        for (let i = 0; i < props.length; i++) {
            frames[i] = new Sprite({name: props.id, x: (i * props.width), y: 0, w: props.width, h: props.height});
        }
        this.spriteAnimation = new SpriteAnimation("#" + this.props.id, frames);
        this.start();
    }

    start() {
        this.render();
        setTimeout(() => {
            this.getElement().style.width = (this.props.width * this.props.length) + "px";
            this.getElement().style.height = this.props.height + "px";
            this.getElement().style.background = "url(" + this.props.src + ") transparent no-repeat";
            this.getContainer().style.width = this.props.width + "px";
            this.getContainer().style.height = this.props.height + "px";
            this.enable(true);
        }, 50);
    }

    getContainer() {
        return document.querySelector("#" + this.props.id + "-container");
    }

    getElement() {
        return document.querySelector("#" + this.props.id);
    }

    render() {
        return (
            <button type="button" id={this.props.id + "-container"} className="sprite-button-container">
                <div id={this.props.id} className="sprite-button"></div>
            </button>
        );
    }

    enable(value) {
        console.info( this.spriteAnimation);
        try {
            this.getContainer().removeEventListener("mouseover", this.mouseHandler, false);
            this.getContainer().removeEventListener("mouseout", this.mouseHandler, false);
        } catch(err) {}
        if (value) {
            this.getContainer().addEventListener("mouseover", this.mouseHandler, false);
            this.getContainer().addEventListener("mouseout", this.mouseHandler, false);
        }
    }

    mouseHandler(e) {
        switch(e.type) {
            case "mouseover":
                this.spriteAnimation.playAnimation();
                break;
            case "mouseout":
                this.spriteAnimation.reverseAnimation();
                break;
        }
    }

}

export {SpriteButton};