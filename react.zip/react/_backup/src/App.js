import React, {Component} from 'react';
import './object-assign-polyfill.js';
import {VideoPlayer} from './VideoPlayerReactES6.js';
import {ButtonUtil} from './ButtonUtil.js';
import {SpriteButton} from './SpriteButton.js';
import Sniffer from './Sniffer.js';
import './App.css';
import video_1_mp4 from './video.mp4';
import video_1_webm from './video.webm';
import loader from "./loader.gif";
import spriteTest from "./sprites/test.png";

class App extends Component {

    constructor(data) {
        super(data);
        this.test = null;
        setTimeout(this.componentsLoaded.bind(this), 1000);
    }

    render() {
        return (
            <div className="App">
                <VideoPlayer id="video-player-1"
                             controllerId="video-player-controller-1"
                             width="1012"
                             maxWidth="640"
                             height="620"
                             duration="96000"
                             autoHideControls="true"
                             mp4={video_1_mp4}
                             webm={video_1_webm}
                             loader={loader}
                             autoplay="true"/>
                <SpriteButton id="sprite-button-1" width="75" height="40" length="3" src={spriteTest} />
            </div>
        );
    }

    componentsLoaded() {
        if (!Sniffer.sniff().isMobileDevice) {
            document.querySelector("#video-player-controller-1 button.button-play-video").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-play-video").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-pause-video").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-pause-video").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-mute-video").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-mute-video").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-unmute-video").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-unmute-video").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-start-fullscreen").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-start-fullscreen").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-end-fullscreen").addEventListener("mouseover", ButtonUtil.buttonFaderHandler, false);
            document.querySelector("#video-player-controller-1 button.button-end-fullscreen").addEventListener("mouseout", ButtonUtil.buttonFaderHandler, false);
        }
    }

}

export default App;
