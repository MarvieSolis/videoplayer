
class SpriteAnimation {

    constructor(selector, frames, options) {
        if(!options) options = {};
        let _options = {
            id: options.id || "a-" + ~~(Math.random() * 100000000).toString(),
            loop: options.loop || false,
            position: options.position || {x: 0, y: 0},
            complete: options.complete || null,
            cancelable: options.cancelable || false,
        };
        this.frames = frames || [];
        this.cancelable = _options.cancelable;
        this.complete = _options.complete;
        this.id = _options.id;
        this.loop = _options.loop;
        this.position = _options.position;
        this.counter = 1;
        this.index = 0;
        this.isComplete = false;
        this.isPaused = true;
        this.selector = selector;
        this.container = document.querySelector(selector);
        this.interval = null;
        this.fps = 30;
        this.next = this.next.bind(this);
        this.previous = this.previous.bind(this);
    }

    reverseAnimation() {
        console.log("reverseAnimation");
        this.play();
        clearInterval(this.interval);
        this.interval = setInterval(this.previous, this.fps);
    }

    playAnimation() {
        console.log("playAnimation");
        this.play();
        clearInterval(this.interval);
        this.interval = setInterval(this.next, this.fps);
    }

    _animationComplete() {
        console.log("_animationComplete");
        this.pause();
        clearInterval(this.interval);
        this.interval = null;
    }

    pauseAnimation() {
        console.log("pauseAnimation");
        this.pause();
        clearInterval(this.interval);
        this.interval = null;
    }

    clone() {
        return new SpriteAnimation(
            this.frames.concat(), {
                id: this.id,
                loop: this.loop,
                position: this.position,
                complete: this.complete,
                cancelable: this.cancelable,
            });
    }

    play() {
        if (this.cancelable && (this.index !== 0 && this.index !== this.frames.length - 1)) return;
        this.index = 0;
        this.isComplete = false;
        this.isPaused = false;
    }

    resume() {
        this.isPaused = false;
    }

    pause() {
        this.isPaused = true;
    }

    next() {
        if (this.isPaused) return;
        if (this.isComplete) return;
        if (this.frames.length <= 1) return;
        if (this.index < 0) this.index = 0;
        if (this.index > (this.frames.length - 1)) this.index = (this.frames.length - 1);
        let fs = this.frames[this.index].frameSpeed || 5;
        if (this.counter !== 0 && this.counter % fs === 0) {
            if (this.index < (this.frames.length - 1)) {
                this.index++;
            }
            this.counter = 1;
        }

        if (this.loop) {
            if (this.index === (this.frames.length - 1)) {
                this.index = 0;
            }
        } else if (!this.loop && !this.isComplete && this.index === (this.frames.length - 1)) {
            this.isComplete = true;
            this._animationComplete();
            if (this.complete) {
                this.complete.call(null);
            }
        }
        this.counter = ++this.counter % 10000;
        this.render();
    }

    previous() {
        if (this.isPaused) return;
        if (this.isComplete) return;
        if (this.frames.length <= 1) return;
        if (this.index < 0) this.index = 0;
        if (this.index > (this.frames.length - 1)) this.index = (this.frames.length - 1);
        let fs = this.frames[this.index].frameSpeed || 5;
        if (this.counter !== 0 && this.counter % fs === 0) {
            if (this.index > 0) {
                this.index--;
            }
            this.counter = 1;
        }
        if (this.loop) {
            if (this.index === 0) {
                this.index = (this.frames.length - 1);
            }
        } else if (!this.loop && !this.isComplete && this.index === 0) {
            this.isComplete = true;
            this._animationComplete();
            if (this.complete) {
                this.complete.call(null);
            }
        }
        this.counter = ++this.counter % 10000;
        this.render();
    }

    render() {
        console.log(this.frames[this.index].x);
        document.querySelector(this.selector).style.backgroundPosition = -(this.frames[this.index].x) + "px " + -(this.frames[this.index].y) + "px";
    }

    destroy() {
        this.pauseAnimation();
        this.frames = null;
        this.id = null;
        this.loop = false;
        this.position = null;
        this.complete = null;
        this.index = 0;
        this.counter = 0;
    }

}

export {SpriteAnimation};