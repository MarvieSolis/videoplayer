import Sprite from "Sprite.js";

class BlittingUtils {

    /**
     * parseSpritesheet
     * @param json
     * @param id
     * @param elementId
     * @param callback
     */
    static parseSpritesheet(json, id, elementId, callback) {
        let obj;
        let parsedData = BlittingUtils.parseSpritesFromJSONScript(json, id, elementId);
        for (obj in parsedData) {
            /*console.log(parsedData.id + " - " + obj + ", type: " + typeof parsedData[obj]);*/
            if (typeof obj === "undefined") {
                console.warn("\t\tfound undefined object retry");
                BlittingUtils.parseSpritesheet(parsedData, id, elementId, callback);
                return;
            }
        }
        callback.call(null, parsedData);
    }

    /**
     * parseSpritesFromJSONScript
     * Built for "TexturePacker" formatted json files
     * @param json
     * @param id
     * @param elementId
     */
    static parseSpritesFromJSONScript(json, id, elementId) {
        let i, l, frame, name;
        let sprites = {
            id: id,
            elementId: elementId
        };
        let img = document.getElementById(elementId);
        for (i = 0, l = json.frames.length; i < l; i++) {
            frame = json.frames[i];
            name = frame.filename.substring(0, frame.filename.lastIndexOf("."));
            sprites[name] = new Sprite();
            sprites[name].name = name;
            sprites[name].image = img;
            sprites[name].src = json.meta.image;
            sprites[name].x = parseInt(frame.frame.x);
            sprites[name].y = parseInt(frame.frame.y);
            sprites[name].w = parseInt(frame.frame.w);
            sprites[name].h = parseInt(frame.frame.h);
        }
        /*for(var obj in sprites) {
         console.log(sprites.imageId + " - " + obj + ", type: " + typeof sprites[obj]);
         }*/
        return sprites;
    }

    /**
     * simpleDrawSprite
     * @param context
     * @param sprite
     * @param x
     * @param y
     */
    static simpleDrawSprite(context, sprite, x, y) {
        context.drawImage(sprite.image, sprite.x, sprite.y, sprite.w, sprite.h, x, y, sprite.w, sprite.h);
    }

    /**
     * simpleDrawSpriteXReverse
     * @param context
     * @param sprite
     * @param x
     * @param y
     * @param xOffset
     */
    static simpleDrawSpriteXReverse(context, sprite, x, y, xOffset) {
        context.save();
        context.translate((x + sprite.w + xOffset), y);
        context.scale(-1, 1);
        context.drawImage(sprite.image, sprite.x, sprite.y, sprite.w, sprite.h, 0, 0, sprite.w, sprite.h);
        context.restore();
    }

    /**
     * simpleDrawSpriteYReverse
     * @param context
     * @param sprite
     * @param x
     * @param y
     * @param yOffset
     */
    static simpleDrawSpriteYReverse(context, sprite, x, y, yOffset) {
        context.save();
        context.translate(x, (y + sprite.h + yOffset));
        context.scale(1, -1);
        context.drawImage(sprite.image, sprite.x, sprite.y, sprite.w, sprite.h, 0, 0, sprite.w, sprite.h);
        context.restore();
    }

    /**
     * drawSpriteList
     * Draws sprites that are listed onto the canvas
     * Good for testing that they are being blitted correctly
     * @param context
     * @param sprites
     * @param maxWidth
     */
    static drawSpriteList(context, sprites, maxWidth) {
        let i, l, currRowWidth = 0, sprite, posX = 0, posY = 0, tallestSpriteLastRow = 0, currHeight = 0;
        for (i = 0, l = sprites.length; i < l; i++) {
            sprite = sprites[i];
            if ((currRowWidth + sprite.w) > maxWidth) {
                posX = 0;
                posY = currHeight + tallestSpriteLastRow;
                currHeight += tallestSpriteLastRow;
                currRowWidth = sprite.w;
                tallestSpriteLastRow = 0;
            } else {
                posX = currRowWidth;
                currRowWidth += sprite.w;
            }
            context.drawImage(sprite.image, sprite.x, sprite.y, sprite.w, sprite.h, posX, posY, sprite.w, sprite.h);
            if (tallestSpriteLastRow < sprite.h) tallestSpriteLastRow = sprite.h;
        }
    }

}

export default BlittingUtils;