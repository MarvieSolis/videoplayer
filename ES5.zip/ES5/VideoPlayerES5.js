this.VideoCuepoint = function (id, time) {
    this.id = id;
    this.time = time;
    this.enabled = true;
};

this.VideoCuepoint.constructor = this.VideoCuepoint;

/* ======================================================================================================= */

var loader = "images/loader.gif";
var buttonPlayVideo = "images/button-play-video.png";
var buttonPauseVideo = "images/button-pause-video.png";
var buttonUnmuteVideo = "images/button-unmute-video.png";
var buttonMuteVideo = "images/button-mute-video.png";
var buttonStartFullscreen = "images/button-start-fullscreen.png";
var buttonEndFullscreen = "images/button-end-fullscreen.png";

this.VideoPlayer = function (props) {
    this.props = props;
    this.cuepoints = [];
    this.videoPlaying = this.videoPlaying.bind(this);
    this.videoError = this.videoError.bind(this);
    this.videoComplete = this.videoComplete.bind(this);
    this.videoProgress = this.videoProgress.bind(this);
    this.startFullscreen = this.startFullscreen.bind(this);
    this.endFullscreen = this.endFullscreen.bind(this);
    this.videoFullscreenChangeHandler = this.videoFullscreenChangeHandler.bind(this);
    this.mouseMoveHandler = this.mouseMoveHandler.bind(this);
    this.mouseMovePlayerHandler = this.mouseMovePlayerHandler.bind(this);
    this.mouseUpHandler = this.mouseUpHandler.bind(this);
    this.updateScrubber = this.updateScrubber.bind(this);
    this.scrubHandler = this.scrubHandler.bind(this);
    this.constantTimerHandler = this.constantTimerHandler.bind(this);
    this.play = this.play.bind(this);
    this.pause = this.pause.bind(this);
    this.mute = this.mute.bind(this);
    this.unmute = this.unmute.bind(this);
    this.videoError = this.videoError.bind(this);
    this.startFullscreen = this.startFullscreen.bind(this);
    this.endFullscreen = this.endFullscreen.bind(this);
    this.togglePlayPauseHandler = this.togglePlayPauseHandler.bind(this);
    this.windowFocusHandler = this.windowFocusHandler.bind(this);
    this.uniqueId = parseInt(Math.random() * 100000000);
    this.time = 0;
    this.wasPlayingBeforeScrubbing = false;
    this.isDraggingScrubber = false;
    this.scrubberX = 0;
    this.scrubberMaxX = 0;
    this.scrubberMinX = 0;
    this.scrubberInterval = 0;
    this.leftControlsWidth = 60;
    this.rightControlsWidth = 30;
    this.scrubberHandleOffsetX = 5;
    this.autoHideControlsTimer = 0;
    this.constantVideoPlaybackInterval = 0;
    this._isVideoPlaying = false;
    this.start();
};

this.VideoPlayer.constructor = this.VideoPlayer;

this.VideoPlayer.prototype.start = function () {
    this._isVideoPlaying = false;
    this.time = 0;
    this.render();
    setTimeout(function () {
        this.getContainer().style.opacity = 1;
        this.getElement().muted = true;
        this.getElement().setAttribute("muted", "");
        this.getControl("video-loader").style.display = "block";
        this.getControl("end-fullscreen").style.display = "none";
        this.getControl("video-controls").style.opacity = 1;
        this.getControl("video-progress-container").style.left = (this.leftControlsWidth) + "px";
        this.getElement().parentNode.style.maxWidth = this.props.maxWidth + "px";
        /* TAILOR CONTROLS */
        if (new Sniffer().sniff().data.isMobileDevice) {
            this.leftControlsWidth = 30;
        }
        if (new Sniffer().isIE()) {
            if (new Sniffer().isIE() <= 11) {
                this.rightControlsWidth = 0;
                this.getControl("start-fullscreen").style.display = "none";
                this.getControl("end-fullscreen").style.display = "none";
            }
        }
        if (!this.getFullscreenEnabled()) {
            this.rightControlsWidth = 0;
            this.getControl("start-fullscreen").style.display = "none";
            this.getControl("end-fullscreen").style.display = "none";
        }
        if (new Sniffer().sniff().data.isMobileDevice) {
            this.getControl("mute").style.display = "none";
            this.getControl("unmute").style.display = "none";
        }
        this.updateController();
        if (this.props.autoplay === "true") {
            this.getControl("click-to-play").style.display = "none";
            this.getControl("play").style.display = "none";
            this.getControl("pause").style.display = "block";
            this.play();
        } else {
            this.getControl("click-to-play").style.display = "block";
            this.getControl("play").style.display = "block";
            this.getControl("pause").style.display = "none";
        }
        this.enable(true);
        /* ANIMATIONS */
        new SpriteButton({id: "button-play-video-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonPlayVideo});
        new SpriteButton({id: "button-pause-video-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonPauseVideo});
        new SpriteButton({id: "button-mute-video-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonMuteVideo});
        new SpriteButton({id: "button-unmute-video-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonUnmuteVideo});
        new SpriteButton({id: "button-start-fullscreen-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonStartFullscreen});
        new SpriteButton({id: "button-end-fullscreen-" + this.uniqueId, width: 30, height: 30, length: 2, src: buttonEndFullscreen});
    }.bind(this), 100);
};

this.VideoPlayer.prototype.constantTimerHandler = function () {
    if (this.getAutoHideControls()) {
        if (this.autoHideControlsTimer === this.getAutoHideControlsTime()) {
            this.getControl("video-controls").style.opacity = 0;
        }
        if (this.autoHideControlsTimer === 0) {
            this.getControl("video-controls").style.opacity = 1;
        }
        this.autoHideControlsTimer++;
    }
};

this.VideoPlayer.prototype.destroy = function () {
    this.enable(false);
};

this.VideoPlayer.prototype.render = function () {
    this.getContainer().innerHTML =
        '<video id="' + this.props.id + '" class="video-player" preload="auto" playsInline muted>\
            <source src="' + this.props.mp4 + '" type="video/mp4"></source>\
            <source src="' + this.props.webm + '" type="video/webm"></source>\
        </video>\
        <div class="video-loader">\
            <img src="' + loader + '" alt="loading..."></img>\
        </div>\
        <div id="' + this.props.controllerId + '" class="video-controls-container">\
            <div class="video-controls">\
                <div class="video-progress-container">\
                    <div id="' + "video-bar-" + this.uniqueId + '" class="video-bar">\
                        <div class="video-bar-detail"></div>\
                    </div>\
                    <div id="' + "video-progress-bar-" + this.uniqueId + '" class="video-progress-bar">\
                        <div class="video-progress-bar-detail"></div>\
                    </div>\
                    <div id="' + "video-scrubber-handle-" + this.uniqueId + '" class="video-scrubber-handle">\
                        <div class="video-scrubber-handle-detail"></div>\
                    </div>\
                </div>\
                <button type="button" id="' + "button-play-video-" + this.uniqueId + '" class="sprite-button button-play-video">\
                    <div class="detail"></div>\
                </button>\
                <button type="button" id="' + "button-pause-video-" + this.uniqueId + '" class="sprite-button button-pause-video">\
                    <div class="detail"></div>\
                </button>\
                <button type="button" id="' + "button-unmute-video-" + this.uniqueId + '" class="sprite-button button-unmute-video">\
                    <div class="detail"></div>\
                </button>\
                <button type="button" id="' + "button-mute-video-" + this.uniqueId + '" class="sprite-button button-mute-video">\
                    <div class="detail"></div>\
                </button>\
                <button type="button" id="' + "button-start-fullscreen-" + this.uniqueId + '" class="sprite-button button-start-fullscreen">\
                    <div class="detail"></div>\
                </button>\
                <button type="button" id="' + "button-end-fullscreen-" + this.uniqueId + '" class="sprite-button button-end-fullscreen">\
                    <div class="detail"></div>\
                </button>\
            </div>\
            <button type="button" id="' + "button-toggle-play-pause-" + this.uniqueId + '" class="button-toggle-play-pause"></button>\
            <button type="button" id="' + "button-click-to-play-" + this.uniqueId + '" class="button-click-to-play-video"></button>\
        </div>';
};

this.VideoPlayer.prototype.play = function () {
    this.getControl("video-loader").style.display = "block";
    var isError = false;
    var promise = this.getElement().play();
    if (promise !== undefined) {
        promise.catch(function (error) {
            console.log("video playback error");
            if (error) {
                isError = true;
            }
        }.bind(this)).then(function () {
            this.getControl("video-loader").style.display = "none";
            if (isError) {
                console.warn("video play was prevented");
            } else {
                if ((this.time * 1000) === this.props.duration) {
                    this.resetCuePoints();
                }
                clearInterval(this.videoPlaybackInterval);
                this.videoPlaybackInterval = setInterval(this.videoProgress, 30);
                this._isVideoPlaying = true;
            }
            // this.sendNotification('video error', {}, this);
        }.bind(this));
    }
};

this.VideoPlayer.prototype.getControl = function (label) {
    switch (label) {
        case "controller":
            return document.querySelector("#" + this.props.controllerId);
            break;
        case "play":
            return document.querySelector("#" + this.props.controllerId + " button.button-play-video");
            break;
        case "pause":
            return document.querySelector("#" + this.props.controllerId + " button.button-pause-video");
            break;
        case "mute":
            return document.querySelector("#" + this.props.controllerId + " button.button-mute-video");
            break;
        case "unmute":
            return document.querySelector("#" + this.props.controllerId + " button.button-unmute-video");
            break;
        case "start-fullscreen":
            return document.querySelector("#" + this.props.controllerId + " button.button-start-fullscreen");
            break;
        case "end-fullscreen":
            return document.querySelector("#" + this.props.controllerId + " button.button-end-fullscreen");
            break;
        case "toggle-play-pause":
            return document.querySelector("#" + this.props.controllerId + " button.button-toggle-play-pause");
            break;
        case "click-to-play":
            return document.querySelector("#" + this.props.controllerId + " button.button-click-to-play-video");
            break;
        case "video-loader":
            return document.querySelector("#" + this.props.containerId + " div.video-loader");
            break;
        case "video-bar":
            return document.querySelector("#" + this.props.controllerId + " div.video-bar");
            break;
        case "video-progress-bar":
            return document.querySelector("#" + this.props.controllerId + " div.video-progress-bar");
            break;
        case "video-scrubber-handle":
            return document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle");
            break;
        case "video-progress-container":
            return document.querySelector("#" + this.props.controllerId + " > div.video-controls > div.video-progress-container");
            break;
        case "video-controls":
            return document.querySelector("#" + this.props.controllerId + " div.video-controls");
            break;
        case "video-scrubber-handle-detail":
            return document.querySelector("#" + this.props.controllerId + " div.video-scrubber-handle-detail");
            break;
    }
    return null;
};

this.VideoPlayer.prototype.pause = function () {
    this._isVideoPlaying = false;
    this.getControl("play").style.display = "block";
    this.getControl("pause").style.display = "none";
    this.getElement().pause();
    clearInterval(this.videoPlaybackInterval);
};

this.VideoPlayer.prototype.rewind = function () {
    try {
        this.getElement().currentTime = 0;
    } catch (err) {
    }
    this.resetCuePoints();
    this.pause();
};

this.VideoPlayer.prototype.mute = function () {
    this.getControl("mute").style.display = "none";
    this.getControl("unmute").style.display = "block";
    this.getElement().volume = 0.0;
};

this.VideoPlayer.prototype.unmute = function () {
    this.getControl("mute").style.display = "block";
    this.getControl("unmute").style.display = "none";
    try {
        this.getElement().removeAttribute("muted");
    } catch (err) {
    }
    this.getElement().volume = 1.0;
};

this.VideoPlayer.prototype.startFullscreen = function () {
    var elem = this.getElement().parentNode;
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { /* Firefox */
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE/Edge */
        elem.msRequestFullscreen();
    }
    if (new Sniffer().sniff().data.isMobileDevice) {
        this.getElement().webkitEnterFullscreen();
    } else {
        this.getControl("start-fullscreen").style.display = "none";
        this.getControl("end-fullscreen").style.display = "block";
        if (new Sniffer().isIE()) {
            if (new Sniffer().isIE() <= 11) {
                this.getControl("start-fullscreen").style.display = "none";
                this.getControl("end-fullscreen").style.display = "none";
            }
        }
    }
    this.updateController();
    setTimeout(function () {
        this.updateController();
    }.bind(this), 500);
    setTimeout(function () {
        this.updateController();
    }.bind(this), 1000);
};

this.VideoPlayer.prototype.endFullscreen = function () {
    if (document.fullscreenElement || /* Standard syntax */
        document.webkitFullscreenElement || /* Chrome, Safari and Opera syntax */
        document.mozFullScreenElement ||/* Firefox syntax */
        document.msFullscreenElement /* IE/Edge syntax */) {
        if (document.fullScreenElement) {
            document.cancelFullScreen();
        } else if (document.msFullscreenElement) {
            document.msExitFullscreen();
        } else if (document.mozFullScreenElement) {
            document.mozCancelFullScreen();
        } else if (document.webkitFullscreenElement) {
            document.webkitCancelFullScreen();
        } else {
            document.exitFullscreen();
        }
    }
    this.getControl("start-fullscreen").style.display = "block";
    this.getControl("end-fullscreen").style.display = "none";
    this.updateController();
    this.autoHideControlsTimer = 0;
    setTimeout(function () {
        this.updateController();
    }.bind(this), 500);
    setTimeout(function () {
        this.updateController();
    }.bind(this), 1000);
};

this.VideoPlayer.prototype.replay = function () {
    this.resetCuePoints();
    this.rewind();
    this.unmute();
    this.play();
};

this.VideoPlayer.prototype.videoError = function () {
    this.getControl("video-loader").style.display = "block";
    console.warn("video error");
    clearInterval(this.videoPlaybackInterval);
    // this.sendNotification('video error', {}, this);
};

this.VideoPlayer.prototype.videoPlaying = function () {
    this.autoHideControlsTimer = 0;
    this._isVideoPlaying = true;
    this.getControl("video-loader").style.display = "none";
    // play/pause
    this.getControl("play").style.display = "none";
    this.getControl("pause").style.display = "block";
    // mute/unmute
    if (new Sniffer().sniff().data.isMobileDevice) {
        this.getControl("mute").style.display = "none";
        this.getControl("unmute").style.display = "none";
    } else {
        if (this.getElement().volume === 0) {
            this.getControl("mute").style.display = "none";
            this.getControl("unmute").style.display = "block";
        } else {
            this.getControl("mute").style.display = "block";
            this.getControl("unmute").style.display = "none";
        }
    }
    this.getControl("click-to-play").style.display = "none";
    this.getControl("video-controls").style.opacity = 1;
    this.wasPlayingBeforeScrubbing = true;
    clearInterval(this.videoPlaybackInterval);
    this.videoPlaybackInterval = setInterval(this.videoProgress, 30);
    // this.sendNotification('playing', {}, this);
};

this.VideoPlayer.prototype.videoProgress = function () {
    try {
        if (!this.getElement().currentTime) return;
        var i = 0;
        if (this.time > this.getElement().currentTime) {
            for (i = 0; i < this.cuepoints.length; i++) {
                this.cuepoints[i].enabled = true;
            }
        }
        this.time = this.getCurrentTime();
        for (i = 0; i < this.cuepoints.length; i++) {
            if (this.cuepoints[i].enabled) {
                if (((parseFloat(this.time) - 0.1) < this.cuepoints[i].time &&
                    (parseFloat(this.time) + 0.1) > this.cuepoints[i].time) ||
                    this.time === this.cuepoints[i].time) {
                    this.cuepoints[i].enabled = false;
                    // this.sendNotification(this.cuepoints[i].id, {time: this.cuepoints[i].time}, this);
                }
            }
        }
        var progressBarWidth = parseInt(window.getComputedStyle(this.getControl("video-bar"), null).width);
        this.scrubberMaxX = progressBarWidth;
        this.scrubberMinX = 10;
        var duration = (this.props.duration * 0.001);
        try {
            var currentTime = this.getElement().currentTime;
            if (currentTime > duration) currentTime = duration;
            if (currentTime < 0) currentTime = 0;
            this.scrubberX = parseInt((currentTime / duration) * progressBarWidth);
            this.scrubberX = Math.max(this.scrubberMaxX);
            this.scrubberX = Math.min(this.scrubberMinX);
            this.updateScrubber();
        } catch (err) {
            console.warn("control error: " + err.message);
            this.getControl("video-progress-container").style.display = "none";
        }
        var val = (this.time / duration) * this.scrubberMaxX;
        this.getControl("video-progress-bar").style.width = val + "px";
        this.getControl("video-scrubber-handle").style.left = (val - 10) + "px";
        // Update progress bar
        var w = this.props.width;
        if (this.isFullscreen()) {
            w = window.innerWidth;
        } else {
            w = window.getComputedStyle(this.getElement(), null).width.toString();
        }
        this.getControl("video-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
        /*this.sendNotification("progress", {
            time: this.getElement().currentTime,
            duration: this.props.duration
        }, this);*/
    } catch (err) {
    }
};

this.VideoPlayer.prototype.videoComplete = function (e) {
    clearInterval(this.videoPlaybackInterval);
    this._isVideoPlaying = false;
    if (new Sniffer().sniff().data.isMobileDevice) {
        this.getElement().webkitExitFullscreen();
    }
    this.getControl("click-to-play").style.display = "block";
    setTimeout(function () {
        // this.sendNotification("ended", {}, this);
    }.bind(this), 10);
};

this.VideoPlayer.prototype.videoFullscreenChangeHandler = function () {
    this.updateController();
    if (this.isFullscreen()) {
        this.getElement().parentNode.style.maxWidth = "none";
        this.getControl("start-fullscreen").style.display = "none";
        this.getControl("end-fullscreen").style.display = "block";
    } else {
        this.getElement().parentNode.style.maxWidth = this.props.maxWidth + "px";
        this.getControl("start-fullscreen").style.display = "block";
        this.getControl("end-fullscreen").style.display = "none";
    }
    var w = window.getComputedStyle(this.getElement(), null).width.toString();
    this.getControl("video-progress-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
};

this.VideoPlayer.prototype.getCurrentTime = function () {
    return parseFloat(this.getElement().currentTime).toFixed(2);
};

this.VideoPlayer.prototype.getContainer = function () {
    return document.getElementById(this.props.containerId);
};

this.VideoPlayer.prototype.getElement = function () {
    return document.getElementById(this.props.id);
};

this.VideoPlayer.prototype.deleteElement = function () {
    this.getContainer().innerHTML = "";
};

this.VideoPlayer.prototype.addCuepoint = function (id, time) {
    this.cuepoints.push(new VideoCuepoint(id, time));
};

this.VideoPlayer.prototype.removeCuepoints = function () {
    this.cuepoints = []
};

this.VideoPlayer.prototype.resetCuePoints = function () {
    var i, l;
    for (i = 0, l = this.cuepoints.length; i < l; i++) {
        this.cuepoints[i].enabled = true;
    }
};

this.VideoPlayer.prototype.mouseUpHandler = function (e) {
    this.mouseMoveHandler(e);
    if (this.isDraggingScrubber) {
        if (this.wasPlayingBeforeScrubbing) {
            try {
                this.play();
            } catch (err) {
            }
        }
    }
    this.stopDragging();
};

this.VideoPlayer.prototype.mouseMovePlayerHandler = function (e) {
    this.autoHideControlsTimer = 0;
};

this.VideoPlayer.prototype.mouseMoveHandler = function (e) {
    if (this.isDraggingScrubber) {
        this.autoHideControlsTimer = 0;
        var progressBarWidth = parseFloat(window.getComputedStyle(this.getControl("video-bar")).width);
        var currentTime = 0;
        var duration = this.props.duration * 0.001;
        var interactionX = 0;
        if (new Sniffer().sniff().data.isMobileDevice) {
            interactionX = e.changedTouches[0].clientX;
        } else {
            interactionX = e.clientX;
        }
        try {
            this.scrubberX = (interactionX + this.scrubberHandleOffsetX - this.leftControlsWidth);
            if (this.scrubberX > this.scrubberMaxX) this.scrubberX = this.scrubberMaxX;
            if (this.scrubberX < this.scrubberMinX) this.scrubberX = this.scrubberMinX;
            currentTime = (this.scrubberX / progressBarWidth) * this.props.duration;
            currentTime *= 0.001;
            if (currentTime > duration) currentTime = duration;
            if (currentTime < 0) currentTime = 0;
            this.getElement().currentTime = currentTime;
            this.updateScrubber();
        } catch (err) {
        }
    }
};

this.VideoPlayer.prototype.scrubHandler = function (e) {
    if (this.isVideoPlaying()) {
        this.pause();
    }
    this.isDraggingScrubber = true;
    this.mouseMoveHandler(e);
    this.updateScrubber();
    clearInterval(this.scrubberInterval);
    this.scrubberInterval = setInterval(this.updateScrubber, 100);
};

this.VideoPlayer.prototype.updateScrubber = function () {
    this.getControl("video-progress-bar").style.width = this.scrubberX + "px";
    this.getControl("video-scrubber-handle").style.left = (this.scrubberX - 10) + "px";
};

this.VideoPlayer.prototype.stopDragging = function () {
    clearInterval(this.scrubberInterval);
    this.scrubberInterval = 0;
    this.isDraggingScrubber = false;
};

this.VideoPlayer.prototype.updateController = function () {
    if (this.isFullscreen()) {
        this.getElement().style.width = "100%";
        this.getElement().style.height = "100%";
        this.getControl("controller").style.width = "100%";
        this.getControl("controller").style.height = "100%";
        this.getControl("video-controls").style.width = "100%";
        this.getControl("click-to-play").style.width = "100%";
        this.getControl("click-to-play").style.height = "100%";
        this.getControl("video-loader").style.width = "100%";
        this.getControl("video-loader").style.height = "100%";
    }
    var w = window.getComputedStyle(this.getElement(), null).width.toString();
    this.getControl("video-bar").style.width = (parseInt(w) - this.leftControlsWidth - this.rightControlsWidth - 10) + "px";
};

this.VideoPlayer.prototype.togglePlayPauseHandler = function () {
    if (this.isVideoPlaying()) {
        this.pause();
    } else {
        this.play();
    }
};

this.VideoPlayer.prototype.windowFocusHandler = function (e) {
    this.pause();
};

this.VideoPlayer.prototype.enable = function (value) {
    var moveEvent = "mousemove";
    var downEvent = "mousedown";
    var upEvent = "mouseup";
    if (new Sniffer().sniff().data.isMobileDevice) {
        moveEvent = "touchmove";
        downEvent = "touchstart";
        upEvent = "touchend";
    }
    // HANDLERS
    try {
        document.removeEventListener("fullscreenchange", this.videoFullscreenChangeHandler, false);
        document.removeEventListener("mozfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.removeEventListener("webkitfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.removeEventListener("msfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.removeEventListener(moveEvent, this.mouseMoveHandler, false);
        document.removeEventListener(upEvent, this.mouseUpHandler, false);
    } catch (err) {
    }
    clearInterval(this.constantVideoPlaybackInterval);
    if (value) {
        document.addEventListener("fullscreenchange", this.videoFullscreenChangeHandler, false);
        document.addEventListener("mozfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.addEventListener("webkitfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.addEventListener("msfullscreenchange", this.videoFullscreenChangeHandler, false);
        document.addEventListener(moveEvent, this.mouseMoveHandler, false);
        document.addEventListener(upEvent, this.mouseUpHandler, false);
        this.constantVideoPlaybackInterval = setInterval(this.constantTimerHandler, 500);
    }
    try {
        this.getControl("controller").removeEventListener(downEvent, this.mouseMoveHandler, false);
        this.getControl("controller").removeEventListener("mousemove", this.mouseMovePlayerHandler, false);
        this.getControl("video-bar").removeEventListener(downEvent, this.scrubHandler, false);
        this.getControl("video-progress-bar").removeEventListener(downEvent, this.scrubHandler, false);
        this.getControl("video-scrubber-handle").removeEventListener(downEvent, this.scrubHandler, false);
        this.getControl("play").removeEventListener(downEvent, this.play, false);
        this.getControl("pause").removeEventListener(downEvent, this.pause, false);
        this.getControl("mute").removeEventListener(downEvent, this.mute, false);
        this.getControl("unmute").removeEventListener(downEvent, this.unmute, false);
        this.getControl("start-fullscreen").removeEventListener(downEvent, this.startFullscreen, false);
        this.getControl("end-fullscreen").removeEventListener(downEvent, this.endFullscreen, false);
        this.getControl("click-to-play").removeEventListener(downEvent, this.play, false);
        this.getControl("toggle-play-pause").removeEventListener(downEvent, this.togglePlayPauseHandler, false);
        this.getElement().removeEventListener("playing", this.videoPlaying, false);
        this.getElement().removeEventListener("ended", this.videoComplete, false);
        window.removeEventListener("blur", this.windowFocusHandler, false);
    } catch (err) {
    }
    if (value) {
        this.getControl("controller").addEventListener(downEvent, this.mouseMoveHandler, false);
        this.getControl("controller").addEventListener("mousemove", this.mouseMovePlayerHandler, false);
        this.getControl("video-bar").addEventListener(downEvent, this.scrubHandler, false);
        this.getControl("video-progress-bar").addEventListener(downEvent, this.scrubHandler, false);
        this.getControl("video-scrubber-handle").addEventListener(downEvent, this.scrubHandler, false);
        this.getControl("play").addEventListener(downEvent, this.play, false);
        this.getControl("pause").addEventListener(downEvent, this.pause, false);
        this.getControl("mute").addEventListener(downEvent, this.mute, false);
        this.getControl("unmute").addEventListener(downEvent, this.unmute, false);
        this.getControl("start-fullscreen").addEventListener(downEvent, this.startFullscreen, false);
        this.getControl("end-fullscreen").addEventListener(downEvent, this.endFullscreen, false);
        this.getControl("click-to-play").addEventListener(downEvent, this.play, false);
        this.getControl("toggle-play-pause").addEventListener(downEvent, this.togglePlayPauseHandler, false);
        this.getElement().addEventListener("playing", this.videoPlaying, false);
        this.getElement().addEventListener("ended", this.videoComplete, false);
        window.addEventListener("blur", this.windowFocusHandler, false);
    }
};

this.VideoPlayer.prototype.isVideoPlaying = function () {
    return this._isVideoPlaying;
};

this.VideoPlayer.prototype.isVideoComplete = function () {
    if (this.getElement().currentTime === this.props.duration) {
        return true;
    }
    return false;
};

this.VideoPlayer.prototype.isFullscreen = function () {
    if (document.fullscreenElement || /* Standard syntax */
        document.webkitFullscreenElement || /* Chrome, Safari and Opera syntax */
        document.mozFullScreenElement ||/* Firefox syntax */
        document.msFullscreenElement /* IE/Edge syntax */) {
        return true;
    } else {
        return false;
    }
};

this.VideoPlayer.prototype.getAutoHideControls = function () {
    if (this.props.autoHideControls) {
        if (this.props.autoHideControls === "true") {
            return true;
        }
    }
    return false;
};

this.VideoPlayer.prototype.getAutoHideControlsTime = function () {
    if (this.props.autoHideControlsTime) {
        return this.props.autoHideControlsTime;
    }
    return 5;
};

this.VideoPlayer.prototype.getFullscreenEnabled = function () {
    if (document.fullscreenEnabled ||
        document.webkitFullscreenEnabled ||
        document.mozFullScreenEnabled ||
        document.msFullscreenEnabled) {
        return true;
    }
    return false;
};
