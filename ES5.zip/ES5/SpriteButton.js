
this.SpriteButton = function (props) {
    this.props = props;
    this.mouseHandler = this.mouseHandler.bind(this);
    this.spriteAnimation = null;
    this.start();
};

this.SpriteButton.constructor = this.SpriteButton;

this.SpriteButton.prototype.start = function () {
    this.render();
    setTimeout(function() {
        var frames = [];
        for (var i = 0; i < this.props.length; i++) {
            frames[i] = new Sprite({
                name: this.props.id,
                x: (i * parseInt(this.props.width)), y: 0,
                w: parseInt(this.props.width), h: parseInt(this.props.height),
            });
        }
        this.spriteAnimation = new SpriteAnimation("#" + this.props.id + " div.detail", frames, 15);
        this.getElementDetail().style.width = (this.props.width * this.props.length) + "px";
        this.getElementDetail().style.height = this.props.height + "px";
        this.getElementDetail().style.background = "url(" + this.props.src + ") transparent no-repeat";
        this.getElement().style.width = this.props.width + "px";
        this.getElement().style.height = this.props.height + "px";
        this.enable(true);
    }.bind(this), 50);
};

this.SpriteButton.prototype.getElement = function () {
    return document.querySelector("#" + this.props.id);
};

this.SpriteButton.prototype.getElementDetail = function () {
    return document.querySelector("#" + this.props.id + " > div.detail");
};

this.SpriteButton.prototype.render = function () {
    return '<button type="button" id="' + this.props.id + '" class="' + "sprite-button " + this.props.className + '">\
                <div class="detail"></div>\
            </button>';
};

this.SpriteButton.prototype.enable = function (value) {
    try {
        this.getElement().removeEventListener("mouseover", this.mouseHandler, false);
        this.getElement().removeEventListener("mouseout", this.mouseHandler, false);
    } catch (err) {
    }
    if (value) {
        this.getElement().addEventListener("mouseover", this.mouseHandler, false);
        this.getElement().addEventListener("mouseout", this.mouseHandler, false);
    }
};

this.SpriteButton.prototype.mouseHandler = function (e) {
    switch (e.type) {
        case "mouseover":
            this.spriteAnimation.playAnimation();
            break;
        case "mouseout":
            this.spriteAnimation.reverseAnimation();
            break;
    }
};
