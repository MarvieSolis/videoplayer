
var videoPlayer = null;

window.onload = function() {
    videoPlayer = new VideoPlayer({
        id: "video-player-1",
        containerId: "video-player-1-container",
        controllerId: "video-player-1-controller",
        width: "1012",
        height: "620",
        maxWidth: "700",
        duration: "96000",
        autoHideControls: "true",
        mp4: "videos/video.mp4",
        webm: "videos/video.webm",
        autoplay: "true",
    });
};