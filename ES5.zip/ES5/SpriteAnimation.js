this.SpriteAnimation = function (selector, frames, intervalSpeed, options) {
    if (!options) options = {};
    var _options = {
        id: options.id || "a-" + ~~(Math.random() * 100000000).toString(),
        loop: options.loop || false,
        position: options.position || {x: 0, y: 0},
        complete: options.complete || null,
        cancelable: options.cancelable || false,
    };
    this.frames = frames || [];
    this.cancelable = _options.cancelable;
    this.complete = _options.complete;
    this.id = _options.id;
    this.loop = _options.loop;
    this.position = _options.position;
    this.counter = 1;
    this.index = 0;
    this.isComplete = false;
    this.isPaused = true;
    this.selector = selector;
    this.interval = null;
    this.intervalSpeed = intervalSpeed;
    this.next = this.next.bind(this);
    this.previous = this.previous.bind(this);
};

this.SpriteAnimation.constructor = this.SpriteAnimation;

this.SpriteAnimation.prototype.reverseAnimation = function () {
    this.play();
    clearInterval(this.interval);
    this.interval = setInterval(this.previous, this.intervalSpeed);
};

this.SpriteAnimation.prototype.playAnimation = function () {
    this.play();
    clearInterval(this.interval);
    this.interval = setInterval(this.next, this.intervalSpeed);
};

this.SpriteAnimation.prototype._animationComplete = function () {
    clearInterval(this.interval);
    this.interval = null;
};

this.SpriteAnimation.prototype.pauseAnimation = function () {
    this.pause();
    clearInterval(this.interval);
    this.interval = null;
};

this.SpriteAnimation.prototype.clone = function () {
    return new SpriteAnimation(
        this.frames.concat(), {
            id: this.id,
            loop: this.loop,
            position: this.position,
            complete: this.complete,
            cancelable: this.cancelable,
        });
};

this.SpriteAnimation.prototype.getElement = function () {
    return document.querySelector(this.selector);
};

this.SpriteAnimation.prototype.play = function () {
    if (this.cancelable && (this.index !== 0 && this.index !== this.frames.length - 1)) return;
    // this.index = 0;
    this.isComplete = false;
    this.isPaused = false;
};

this.SpriteAnimation.prototype.reset = function () {
    this.index = 0;
};

this.SpriteAnimation.prototype.resume = function () {
    this.isPaused = false;
};

this.SpriteAnimation.prototype.pause = function () {
    this.isPaused = true;
};

this.SpriteAnimation.prototype.next = function () {
    if (this.isPaused) return;
    if (this.isComplete) return;
    if (this.frames.length <= 1) return;
    if (this.index < 0) this.index = 0;
    if (this.index > (this.frames.length - 1)) this.index = (this.frames.length - 1);
    var fs = this.frames[this.index].frameSpeed || 5;
    if (this.counter !== 0 && this.counter % fs === 0) {
        if (this.index < (this.frames.length - 1)) {
            this.index++;
        }
        this.counter = 1;
    }
    if (this.loop) {
        if (this.index === (this.frames.length - 1)) {
            this.index = 0;
        }
    } else if (!this.loop && !this.isComplete && this.index === (this.frames.length - 1)) {
        this.isComplete = true;
        this._animationComplete();
        if (this.complete) {
            this.complete.call(null);
        }
    }
    this.counter = ++this.counter % 10000;
    this.render();
};

this.SpriteAnimation.prototype.previous = function () {
    if (this.isPaused) return;
    if (this.isComplete) return;
    if (this.frames.length <= 1) return;
    if (this.index < 0) this.index = 0;
    if (this.index > (this.frames.length - 1)) this.index = (this.frames.length - 1);
    var fs = this.frames[this.index].frameSpeed || 5;
    if (this.counter !== 0 && this.counter % fs === 0) {
        if (this.index > 0) {
            this.index--;
        }
        this.counter = 1;
    }
    if (this.loop) {
        if (this.index === 0) {
            this.index = (this.frames.length - 1);
        }
    } else if (!this.loop && !this.isComplete && this.index === 0) {
        this.isComplete = true;
        this._animationComplete();
        if (this.complete) {
            this.complete.call(null);
        }
    }
    this.counter = ++this.counter % 10000;
    this.render();
};

this.SpriteAnimation.prototype.render = function () {
    document.querySelector(this.selector).style.backgroundPosition = -(this.frames[this.index].x) + "px " + -(this.frames[this.index].y) + "px";
};

this.SpriteAnimation.prototype.destroy = function () {
    this.pauseAnimation();
    this.frames = null;
    this.id = null;
    this.loop = false;
    this.position = null;
    this.complete = null;
    this.index = 0;
    this.counter = 0;
};
