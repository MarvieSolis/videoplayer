import BlittingUtils from "BlittingUtils.js";

class AnimationFrame {

    constructor(options) {
        if(!options) options = {};
        let _options = {
            sprite: options.sprite || null,
            x: options.x || 0,
            y: options.y || 0,
            rx: options.rx || 0,
            ry: options.ry || 0,
            frameSpeed: options.frameSpeed || 0,
        };
        this.sprite = _options.sprite;
        this.x = _options.x;
        this.y = _options.y;
        this.rx = _options.rx;
        /* reversed frame xoffset */
        this.ry = _options.ry;
        /* reversed frame yoffset */
        this.frameSpeed = _options.frameSpeed;
    }

}

class BlitAnimation {

    constructor(canvas, context, frames, options) {
        if(!options) options = {};
        let _options = {
            id: options.id || "a-" + ~~(Math.random() * 100000000).toString(),
            loop: options.loop || false,
            position: options.position || {x: 0, y: 0},
            complete: options.complete || null,
            cancelable: options.cancelable || false,
        };
        this.canvas = canvas;
        this.context = context;
        this.frames = frames || [];
        this.cancelable = _options.cancelable;
        this.complete = _options.complete;
        this.id = _options.id;
        this.loop = _options.loop;
        this.position = _options.position;
        this.counter = 1;
        this.index = 0;
        this.isComplete = false;
        this.isPaused = true;
    }

    clone() {
        return new BlitAnimation(
            this.canvas,
            this.context,
            this.frames.concat(), {
                id: this.id,
                loop: this.loop,
                position: this.position,
                complete: this.complete,
                cancelable: this.cancelable,
            });
    }

    play() {
        if (this.cancelable && (this.index !== 0 && this.index !== this.frames.length - 1)) return;
        this.index = 0;
        this.isComplete = false;
        this.isPaused = false;
    }

    resume() {
        this.isPaused = false;
    }

    pause() {
        this.isPaused = true;
    }

    update(dt) {
        if (this.isPaused) return;
        if (this.isComplete) return;
        if (this.frames.length <= 1) return;
        if (this.index < 0) this.index = 0;
        if (this.index > (this.frames.length - 1)) this.index = (this.frames.length - 1);
        let fs = this.frames[this.index].frameSpeed || 5;
        if (this.counter !== 0 && this.counter % fs === 0) {
            if (this.index < (this.frames.length - 1)) {
                this.index++;
            }
            this.counter = 1;
        }
        if (this.loop) {
            if (this.index === (this.frames.length - 1)) {
                this.index = 0;
            }
        } else if (!this.loop && !this.isComplete && this.index === (this.frames.length - 1)) {
            this.isComplete = true;
            if (this.complete) this.complete.call(null);
        }
        this.counter = ++this.counter % 10000;
    }

    render(dt, options) {
        if(!options) options = {};
        let _options = {
            xOffset: options.xOffset || 0,
            yOffset: options.yOffset || 0,
        };
        BlittingUtils.simpleDrawSprite(
            this.context,
            this.frames[this.index].sprite,
            this.frames[this.index].x + this.position.x + _options.xOffset,
            this.frames[this.index].y + this.position.y + _options.yOffset);
    }

    renderXReverse(dt, options) {
        if(!options) options = {};
        let _options = {
            xOffset: options.xOffset || 0,
            yOffset: options.yOffset || 0,
        };
        BlittingUtils.simpleDrawSpriteXReverse(
            this.context,
            this.frames[this.index].sprite,
            this.frames[this.index].x + this.position.x + _options.xOffset,
            this.frames[this.index].y + this.position.y + _options.yOffset,
            this.frames[this.index].rx);
    }

    renderYReverse(dt) {
        BlittingUtils.simpleDrawSpriteYReverse(
            this.context,
            this.frames[this.index].sprite,
            this.frames[this.index].x + this.position.x,
            this.frames[this.index].y + this.position.y,
            this.frames[this.index].ry);
    }

    destroy() {
        this.pause();
        this.canvas = null;
        this.context = null;
        this.frames = null;
        this.id = null;
        this.loop = false;
        this.position = null;
        this.complete = null;
        this.index = 0;
        this.counter = 0;
    }

}

export {BlitAnimation, AnimationFrame};