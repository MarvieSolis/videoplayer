this.Sniffer = function() {};

Sniffer.constructor = Sniffer;

Sniffer.prototype.sniff = function() {
    var sniffData = {};
    sniffData.isMobileDevice = false;

    sniffData.isTabletDevice = false;
    sniffData.isAndroidDevice = navigator.userAgent.toLowerCase().indexOf("android") > -1;
    sniffData.isIE = navigator.userAgent.indexOf('MSIE') > -1;
    sniffData.isIE8OrLess = false;
    sniffData.isIE9 = false;
    sniffData.isIE10 = false;
    sniffData.isIE11 = !!navigator.userAgent.match(/Trident\/7\./);
    sniffData.isEdge = (document.documentMode || /Edge/.test(navigator.userAgent));
    sniffData.isEdge = (sniffData.isEdge.toString() === "true");
    sniffData.isAndroidBrowser = "unknown";
    var sAgent = window.navigator.userAgent;
    var Idx = sAgent.indexOf("MSIE");

    if (Idx > 0 || sniffData.isIE) {
        var version = parseInt(sAgent.substring(Idx + 5, sAgent.indexOf(".", Idx)));
        if (version <= 8) sniffData.isIE8OrLess = true;
        if (version === 9) sniffData.isIE9 = true;
        if (version === 10) sniffData.isIE10 = true;
    }
    if (sniffData.isIE11 || sniffData.isIE10 || sniffData.isIE9 || sniffData.isIE8OrLess) sniffData.isIE = true;
    sniffData.isChrome = navigator.userAgent.indexOf('Chrome') > -1;
    if (sniffData.isEdge) sniffData.isChrome = false;
    sniffData.isSafari = navigator.userAgent.indexOf("Safari") > -1;
    if (sniffData.isEdge) sniffData.isSafari = false;
    if ((sniffData.isChrome) && (sniffData.isSafari)) sniffData.isSafari = false;
    sniffData.isFirefox = navigator.userAgent.indexOf('Firefox') > -1;
    sniffData.isOpera = navigator.userAgent.indexOf("Presto") > -1;
    sniffData.OSName = "Unknown OS";
    if (navigator.appVersion.indexOf("Win") !== -1) sniffData.OSName = "Windows";
    if (navigator.appVersion.indexOf("Mac") !== -1) sniffData.OSName = "MacOS";
    var detectedDevice = this.detect().device;
    switch (detectedDevice) {
            case "phone" :
            case "mobile" :
                sniffData.isMobileDevice = true;
                break;
            case "tablet" :
                sniffData.isTabletDevice = true;
                sniffData.isMobileDevice = true;
                break;
            default :
                sniffData.isMobileDevice = false;
                break;
        }

    if (sniffData.isIE) {
            sniffData.isTabletDevice = false;

        sniffData.isMobileDevice = false;
    }
    if (sniffData.isAndroidDevice && sniffData.isMobileDevice && sniffData.isSafari) {
            sniffData.isAndroidBrowser = "maybe";

        sniffData.isSafari = false;
    }
    var arr = [
        {isMobileDevice: sniffData.isMobileDevice},
        {isTabletDevice: sniffData.isTabletDevice},
        {isAndroidDevice: sniffData.isAndroidDevice},
        {isChrome: sniffData.isChrome},
        {isIE: sniffData.isIE},
        {isIE8OrLess: sniffData.isIE8OrLess},
        {isIE9: sniffData.isIE9},
        {isIE10: sniffData.isIE10},
        {isIE11: sniffData.isIE11},
        {isEdge: sniffData.isEdge},
        {isFirefox: sniffData.isFirefox},
        {isSafari: sniffData.isSafari},
        {isOpera: sniffData.isOpera},
        {isAndroidBrowser: sniffData.isAndroidBrowser},
        {OSName: sniffData.OSName},
    ];

    var sniff = "";
    var obj = null;
    var obj2 = null;
    for (obj in arr) {
        for (obj2 in arr[obj]) {
            if (arr[obj][obj2].toString() !== "false") sniff += "" + obj2 + ": " + arr[obj][obj2] + "\n";
        }
    }
    return {
            data: sniffData,
            str: sniff
        };
};

Sniffer.prototype.detect = function() {
    return function () {
        var b = navigator.userAgent.toLowerCase(), a = function (a) {
            void 0 !== a && (b = a.toLowerCase());
            return /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(b) ? "tablet" : /(mobi|ipod|phone|blackberry|opera mini|fennec|minimo|symbian|psp|nintendo ds|archos|skyfire|puffin|blazer|bolt|gobrowser|iris|maemo|semc|teashark|uzard)/.test(b) ? "phone" : "desktop"
        };
        return {device: a(), detect: a, isMobile: "desktop" !== a() ? !0 : !1, userAgent: b}
    }();
};

Sniffer.prototype.getParameterByName = function(name) {
    name = name.replace(/[[]/, "[").replace(/[]]/, "\\]");
    var key = {};
    var value = {};
    const params = {};
    document.location.search.substr(1).split('&').forEach(pair => {
        [key, value] = pair.split('=');
        params[key] = value;
    });
    var valuePair = null;
    if (params[name]) {
        valuePair = decodeURIComponent(params[name].replace(/\+/g, " "));
    }
    return params[name] === null ? "" : valuePair;
};

/**
 * detect IE
 * returns version of IE or false, if browser is not Internet Explorer
 */
Sniffer.prototype.isIE = function() {
    var ua = window.navigator.userAgent;

    // Test values; Uncomment to check result …

    // IE 10
    // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';

    // IE 11
    // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';

    // Edge 12 (Spartan)
    // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';

    // Edge 13
    // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';
    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
            // Edge (IE 12+) => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);

        }
    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
            // IE 11 => return version number
            var rv = ua.indexOf('rv:');
            return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);

        }
    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
            // other browser
            return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);

        }
    return false;
};